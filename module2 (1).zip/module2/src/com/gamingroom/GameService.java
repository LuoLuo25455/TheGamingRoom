package com.gamingroom;

import java.util.ArrayList;
import java.util.List;
import java.util.*;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;

	// FIXME: Add missing pieces to turn this class a singleton 
	/* IMPORTANCE:making the constructor private to prevent this class from being instantiated
	 * CHARACTERISTICS: the class has a private no-arg constructor, a static object created, and a static method return the only object created  
	 */
	
	// creating a static object for GameService
	private static GameService object = new GameService();
	
	// creating a no-arg constructor to prevent this class from being instantiated
	private GameService() {};
	
	// returning the object to get the only object available
	private static GameService getGame() {
		return object;
	}


	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	public Game addGame(String name) {

		// a local game instance
		Game game = null;

		// FIXME: Use iterator to look for existing game with same name
		// if found, simply return the existing instance
		
		// iterating by using for-each loop
		// defining Game g to be each element in arrayList games
		for(Game g:games) {
			/* check if there is a matching name between g and game
			 * if there is a match, then referencing game to g so that game will not be null and will not be added into arrayList games
			 */
			if(g.getName().equals(game.getName())) {
				game = g;
				break;
			}
		}

		// if not found, make a new game instance and add to list of games
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		// FIXME: Use iterator to look for existing game with same id
		// if found, simply assign that instance to the local variable
		
		// iterating by using for-each loop
		// defining Game g to be each element in arrayList games
		for(Game g:games) {
			/* check if there is a matching ID between g and game
			 * if there is a match, then referencing game to g so that they have the same ID
			 */
			if(g.getId() == (game.getId())) {
				game = g;
				break;
			}
		}

		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		// FIXME: Use iterator to look for existing game with same name
		// if found, simply assign that instance to the local variable

		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
}
