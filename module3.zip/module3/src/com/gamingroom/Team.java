package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple class to hold information about a team
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a team is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Team extends Entity{
	long id;
	String name;
	private static List<Team> teams = new ArrayList<Team>();
	/*
	 * Constructor with an identifier and name
	 */
	public Team(long id, String name) {
		this.id = id;
		this.name = name;
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Team [id=" + id + ", name=" + name + "]";
	}
	
	public Team addTeam(String name) {

		// a local team instance
		Team team= null;

		// iterating by using for-each loop
		// defining Team t to be each element in arrayList teams
		for(Team t:teams) {
			/* check if there is a matching name between t and team
			 * if there is a match, then referencing team to t so that team will not be null and will not be added into arrayList teams
			 */
			if(t.getName().equals(team.getName())) {
				team = t;
				break;
			}
		}

		// if not found, add player to list of players
		if (team == null) {
			teams.add(team);
		}

		// return the new/existing team instance to the caller
		return team;
	}
}
