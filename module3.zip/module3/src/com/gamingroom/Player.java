package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple class to hold information about a player
 * <p>
 * Notice the overloaded constructor that requires
 * an id and name to be passed when creating.
 * Also note that no mutators (setters) defined so
 * these values cannot be changed once a player is
 * created.
 * </p>
 * @author coce@snhu.edu
 *
 */
public class Player extends Entity{
	long id;
	String name;
	private static List<Player> players = new ArrayList<Player>();
	
	/*
	 * Constructor with an identifier and name
	 */
	public Player(long id, String name) {
		this.id = id;
		this.name = name;
	}

	/**
	 * @return the id
	 */
	public long getId() {
		return id;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Player [id=" + id + ", name=" + name + "]";
	}
	
	public Player addPlayer(String name) {

		// a local player instance
		Player player= null;

		// iterating by using for-each loop
		// defining Player p to be each element in arrayList players
		for(Player p:players) {
			/* check if there is a matching name between p and player
			 * if there is a match, then referencing player to p so that player will not be null and will not be added into arrayList players
			 */
			if(p.getName().equals(player.getName())) {
				player = p;
				break;
			}
		}

		// if not found, add player to list of players
		if (player == null) {
			players.add(player);
		}

		// return the new/existing player instance to the caller
		return player;
	}
}
